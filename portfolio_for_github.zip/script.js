const FIVERR_URL = "https://www.fiverr.com/"; // Replace with your Fiverr gig link
const YOUR_EMAIL = "example@email.com"; // Replace with your email

document.getElementById("emailLink").href = `mailto:${YOUR_EMAIL}`;